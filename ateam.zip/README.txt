README

Course: cs400
Semester: Fall 2019
Project name: Milk Weight
Team Members:
1. Gunnar Schmitz, 001, goschmitz@wisc.edu
2. Noah Hansen, 001, nphansen@wisc.edu


Other notes or comments to the grader:

It is a little different form the proposal, but not by much.